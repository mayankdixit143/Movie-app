import React from "react";

const Footer = () => {
  return (
    <div
      style={{
        textAlign: "center",
        backgroundColor: "black",
        minHeight: "40px",
      }}
    >
      <div style={{ color: "red", paddingTop: "0.4rem" }}>
        <span style={{ fontWeight: "900" }}> ©️ netflix</span>roulette
      </div>
    </div>
  );
};

export default Footer;
